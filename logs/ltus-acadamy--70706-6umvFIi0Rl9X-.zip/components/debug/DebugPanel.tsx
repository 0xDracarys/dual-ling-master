'use client';

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Bug, X, Download, Trash2, Search, Circle, Square, Minimize2, Maximize2 } from 'lucide-react';
import { DebugLogger, DebugLog, LogLevel, LogCategory } from '@/lib/utils/debug-logger';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const logger = DebugLogger.getInstance();

const LOG_LEVEL_COLORS: Record<LogLevel, string> = {
  debug: 'bg-gray-500',
  info: 'bg-blue-500',
  success: 'bg-green-500',
  warn: 'bg-amber-500',
  error: 'bg-red-500',
};

const LOG_LEVEL_ICONS: Record<LogLevel, string> = {
  debug: '🐛',
  info: 'ℹ️',
  success: '✅',
  warn: '⚠️',
  error: '❌',
};

interface DebugPanelProps {
  defaultOpen?: boolean;
}

export function DebugPanel({ defaultOpen = false }: DebugPanelProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const [isRecording, setIsRecording] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [logs, setLogs] = useState<DebugLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLevel, setSelectedLevel] = useState<LogLevel | 'all'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);
  
  // Panel position and size
  const [position, setPosition] = useState({ x: 20, y: 20 });
  const [size, setSize] = useState({ width: 500, height: 700 });
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [resizeStart, setResizeStart] = useState({ x: 0, y: 0, width: 0, height: 0 });
  const panelRef = useRef<HTMLDivElement>(null);

  // Only render in development (unless explicitly enabled)
  const isEnabled = process.env.NODE_ENV === 'development' || 
                    process.env.NEXT_PUBLIC_ENABLE_DEBUG === 'true';

  useEffect(() => {
    if (!isEnabled) return;

    // Initial load
    setLogs(logger.getLogs());

    // Subscribe to updates (only if recording)
    const unsubscribe = logger.subscribe((updatedLogs) => {
      if (isRecording) {
        setLogs(updatedLogs);
      }
    });

    // Keyboard shortcut: Ctrl+Shift+D
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        e.preventDefault();
        setIsOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      unsubscribe();
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isEnabled, isRecording]);

  // Handle dragging
  useEffect(() => {
    if (!isDragging) return;

    const handleMouseMove = (e: MouseEvent) => {
      const dx = e.clientX - dragStart.x;
      const dy = e.clientY - dragStart.y;
      
      setPosition(prev => ({
        x: Math.max(0, Math.min(window.innerWidth - size.width, prev.x + dx)),
        y: Math.max(0, Math.min(window.innerHeight - size.height, prev.y + dy))
      }));
      
      setDragStart({ x: e.clientX, y: e.clientY });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, dragStart, size]);

  // Handle resizing
  useEffect(() => {
    if (!isResizing) return;

    const handleMouseMove = (e: MouseEvent) => {
      const dx = e.clientX - resizeStart.x;
      const dy = e.clientY - resizeStart.y;
      
      setSize({
        width: Math.max(400, Math.min(window.innerWidth - position.x, resizeStart.width + dx)),
        height: Math.max(400, Math.min(window.innerHeight - position.y, resizeStart.height + dy))
      });
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing, resizeStart, position]);

  const handleDragStart = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleResizeStart = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsResizing(true);
    setResizeStart({
      x: e.clientX,
      y: e.clientY,
      width: size.width,
      height: size.height
    });
  };

  const toggleRecording = () => {
    if (!isRecording) {
      // Start recording - load current logs
      setLogs(logger.getLogs());
      logger.info('Debug', 'Recording started');
    } else {
      // Stop recording
      logger.info('Debug', 'Recording stopped');
    }
    setIsRecording(!isRecording);
  };

  // Filter logs
  const filteredLogs = useMemo(() => {
    let filtered = logs;

    // Filter by level
    if (selectedLevel !== 'all') {
      filtered = filtered.filter(log => log.level === selectedLevel);
    }

    // Filter by category
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(log => log.category === selectedCategory);
    }

    // Search
    if (searchQuery) {
      filtered = logger.searchLogs(searchQuery);
    }

    return filtered.reverse(); // Most recent first
  }, [logs, selectedLevel, selectedCategory, searchQuery]);

  // Get unique categories
  const categories = useMemo(() => {
    const cats = new Set(logs.map(log => log.category));
    return Array.from(cats).sort();
  }, [logs]);

  // Get stats
  const stats = useMemo(() => logger.getStats(), [logs]);

  const handleClearLogs = () => {
    if (confirm('Clear all logs?')) {
      logger.clearLogs();
    }
  };

  const handleDownloadLogs = (format: 'json' | 'csv') => {
    logger.downloadLogs(format);
  };

  const toggleLogExpansion = (logId: string) => {
    setExpandedLogId(prev => prev === logId ? null : logId);
  };

  if (!isEnabled) return null;

  return (
    <>
      {/* Toggle Button (bottom-right corner) */}
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-4 right-4 z-50 rounded-full shadow-lg bg-primary hover:bg-primary/90"
          size="icon"
          title="Open Debug Panel (Ctrl+Shift+D)"
        >
          <Bug className="w-5 h-5" />
        </Button>
      )}

      {/* Debug Panel */}
      {isOpen && (
        <div
          ref={panelRef}
          className="fixed bg-white border-2 border-gray-300 rounded-lg shadow-2xl z-50 flex flex-col"
          style={{
            left: `${position.x}px`,
            top: `${position.y}px`,
            width: `${size.width}px`,
            height: isMinimized ? 'auto' : `${size.height}px`,
            cursor: isDragging ? 'grabbing' : 'default'
          }}
        >
          {/* Header - Draggable */}
          <div
            className="flex items-center justify-between p-4 border-b border-gray-200 bg-gradient-to-r from-purple-50 to-pink-50 cursor-grab active:cursor-grabbing"
            onMouseDown={handleDragStart}
          >
            <div className="flex items-center gap-2">
              <Bug className="w-5 h-5 text-indigo-600" />
              <h3 className="font-semibold text-gray-900">Debug Panel</h3>
              <Badge variant="outline" className="text-xs">
                {stats.total} logs
              </Badge>
            </div>
            <div className="flex items-center gap-1">
              {/* Recording Button */}
              <Button
                variant={isRecording ? "destructive" : "ghost"}
                size="icon"
                onClick={toggleRecording}
                title={isRecording ? "Stop Recording" : "Start Recording"}
                className="relative"
              >
                {isRecording ? (
                  <>
                    <Square className="w-4 h-4 fill-current" />
                    <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                  </>
                ) : (
                  <Circle className="w-4 h-4" />
                )}
              </Button>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => handleDownloadLogs('json')}
                title="Download logs as JSON"
              >
                <Download className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleClearLogs}
                title="Clear all logs"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMinimized(!isMinimized)}
                title={isMinimized ? "Maximize" : "Minimize"}
              >
                {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                title="Close (Ctrl+Shift+D)"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
          
          {/* Recording Status Banner */}
          {isRecording && !isMinimized && (
            <div className="px-4 py-2 bg-red-50 border-b border-red-200 flex items-center gap-2">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-sm font-medium text-red-700">
                Recording in progress...
              </span>
            </div>
          )}

          {/* Filters */}
          {!isMinimized && (
          <div className="p-4 border-b border-gray-200 space-y-3 bg-gray-50">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>

            <div className="flex gap-2">
              <Select value={selectedLevel} onValueChange={(value) => setSelectedLevel(value as LogLevel | 'all')}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="debug">🐛 Debug</SelectItem>
                  <SelectItem value="info">ℹ️ Info</SelectItem>
                  <SelectItem value="success">✅ Success</SelectItem>
                  <SelectItem value="warn">⚠️ Warn</SelectItem>
                  <SelectItem value="error">❌ Error</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="flex-1">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Stats */}
            <div className="flex gap-2 text-xs">
              <Badge variant="secondary" className="bg-red-100 text-red-700 border border-red-200">
                {stats.byLevel.error} errors
              </Badge>
              <Badge variant="secondary" className="bg-amber-100 text-amber-700 border border-amber-200">
                {stats.byLevel.warn} warnings
              </Badge>
              <Badge variant="secondary" className="bg-green-100 text-green-700 border border-green-200">
                {stats.byLevel.success} success
              </Badge>
            </div>
          </div>
          )}

          {/* Logs */}
          {!isMinimized && (
          <ScrollArea className="flex-1 p-4 bg-white">
            {!isRecording ? (
              <div className="text-center text-gray-600 py-12">
                <Circle className="w-12 h-12 mx-auto mb-4 opacity-50 text-gray-400" />
                <p className="font-medium mb-2 text-gray-900">Debug panel is not recording</p>
                <p className="text-sm text-gray-600">Click the record button to start capturing logs</p>
              </div>
            ) : filteredLogs.length === 0 ? (
              <div className="text-center text-gray-600 py-8">
                No logs recorded yet
              </div>
            ) : (
              <div className="space-y-2">
                {filteredLogs.map(log => (
                  <div
                    key={log.id}
                    className="border border-gray-200 rounded-lg p-3 hover:bg-gray-50 cursor-pointer transition-colors bg-white"
                    onClick={() => toggleLogExpansion(log.id)}
                  >
                    <div className="flex items-start gap-2">
                      <span className="text-lg">{LOG_LEVEL_ICONS[log.level]}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-xs border-gray-300">
                            {log.category}
                          </Badge>
                          <span className="text-xs text-gray-500">
                            {new Date(log.timestamp).toLocaleTimeString()}
                          </span>
                        </div>
                        <p className="text-sm font-medium text-gray-900">{log.message}</p>

                        {/* Expanded metadata */}
                        {expandedLogId === log.id && log.metadata && (
                          <pre className="mt-2 p-2 bg-gray-100 border border-gray-200 rounded text-xs overflow-x-auto text-gray-900">
                            {JSON.stringify(log.metadata, null, 2)}
                          </pre>
                        )}

                        {/* Stack trace */}
                        {expandedLogId === log.id && log.stack && (
                          <pre className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-xs overflow-x-auto text-red-700">
                            {log.stack}
                          </pre>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
          )}

          {/* Footer */}
          {!isMinimized && (
          <div className="p-3 border-t border-gray-200 text-xs text-gray-600 flex items-center justify-between bg-gray-50">
            <span>
              Press <kbd className="px-2 py-1 bg-gray-200 border border-gray-300 rounded text-xs font-mono text-gray-900">Ctrl+Shift+D</kbd> to toggle
            </span>
            {/* Resize Handle */}
            <div
              className="cursor-nwse-resize hover:bg-gray-300 rounded p-1 transition-colors text-gray-600"
              onMouseDown={handleResizeStart}
              title="Drag to resize"
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <path d="M15 15L11 15L15 11ZM15 9L7 9L15 1ZM5 15L1 15L1 11L5 15Z" />
              </svg>
            </div>
          </div>
          )}
        </div>
      )}
    </>
  );
}
