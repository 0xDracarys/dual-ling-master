# Phase 3: Pending Tasks & Known Issues

**Status:** 🔴 **ACTIVE**  
**Created:** October 17, 2025  
**Phase:** Phase 3 - Course & Enrollment System  
**Priority:** Track ongoing work and blockers

---

## ✅ **Recently Completed (October 17, 2025)**

### **Dashboard Field Mapping Fixed**
- [x] Updated teacher dashboard to use Firestore field names
- [x] Fixed `course.lessons.length` → `course.lessonsCount`
- [x] Fixed `course.enrolledStudents` → `course.enrollmentCount`
- [x] Fixed `course.rating` → `course.averageRating`
- [x] Updated local Course interface to match Firestore schema
- [x] Fixed course card key (`course._id` → `course.id`)
- [x] Fixed course links to use `course.id` instead of `course._id`

### **Lesson Management System Complete**
- [x] Lesson CRUD API endpoints (GET, POST, PUT, DELETE)
- [x] LessonRepository Firestore operations
- [x] Type-specific lesson content handling
- [x] Auto-generation of description and order fields
- [x] Validation with detailed error messages
- [x] Dialog UI transparency fix
- [x] Lesson creation modal improvements

### **Dashboard Real Data Implementation**
- [x] Created `/api/students/enrolled-courses` endpoint
- [x] Created `/api/students/progress` endpoint  
- [x] Created `/api/teacher/recent-activity` endpoint
- [x] Updated student dashboard to display enrolled courses
- [x] Updated teacher dashboard to show real course data
- [x] Fixed enrollment field mapping in student dashboard
- [x] Refactored teacher recent activity to avoid additional Firestore index
- [x] Created and deployed Firestore composite index (`userId + enrolledAt`)
- [x] **VERIFIED:** Student dashboard shows enrolled courses ✅
- [x] **VERIFIED:** Student enrollment data retrieves successfully ✅

### **Authentication & Authorization**
- [x] Fixed role claims syncing during login
- [x] Implemented automatic token refresh (client-side)
- [x] Fixed Firestore undefined value filtering
- [x] Verified teacher course creation workflow

### **Course Management APIs**
- [x] Added Firebase authentication to PUT `/api/courses/[id]`
- [x] Added Firebase authentication to DELETE `/api/courses/[id]`
- [x] Teachers can now update course title and description
- [x] Teachers can now delete their courses

---

## 🔴 **Known Issues & Pending Tasks**

### **1. Lesson Count Discrepancy** 🔴
**Priority:** P1 - Critical  
**Status:** Under Investigation

**Issue Description:**
- Dashboard shows 2 lessons for a course (CORRECT)
- Course view page shows 1 lesson for same course (INCORRECT)
- Course edit page shows 1 lesson for same course (INCORRECT)
- Terminal logs show "Lesson count incremented { newCount: 2 }" during creation
- Subsequent queries return "Lessons retrieved { count: 1 }"

**Evidence:**
- User created 2 lessons successfully (terminal confirms creation)
- Dashboard displays "2 lessons" correctly
- Other pages only display 1 lesson
- Using same course ID across all pages

**Possible Causes:**
1. Firestore subcollection query issue
2. `publishedOnly` filter excluding unpublished lessons
3. Lesson creation race condition (2nd lesson not fully saved)
4. Caching issue on frontend
5. Different courseId being used (unlikely but possible)

**Investigation Steps:**
1. [ ] Check Firestore console to verify 2 lessons actually exist in database
2. [ ] Add detailed logging to `LessonRepository.getByCourse()` method
3. [ ] Verify `publishedOnly` parameter not being passed incorrectly
4. [ ] Check if both lessons have correct `courseId` reference
5. [ ] Test with hard refresh (clear browser cache)
6. [ ] Add console logging to course/edit page fetch

**Next Steps:**
1. [ ] Verify Firestore data directly in Firebase Console
2. [ ] Add more granular logging to getByCourse query
3. [ ] Test lesson creation with console.log on each step
4. [ ] Check if lessons are in correct subcollection path

**Related Files:**
- `/lib/services/course/lesson.repository.ts` - getByCourse() method
- `/app/course/[id]/page.tsx` - Course view (shows 1)
- `/app/teacher/course/edit/[id]/page.tsx` - Course edit (shows 1)
- `/app/teacher/dashboard/page.tsx` - Dashboard (shows 2 - correct)

---

### **2. Teacher Dashboard - Recent Activity Not Displaying** 🔴
**Priority:** P1 - High  
**Status:** Pending Investigation

**Issue Description:**
- Teacher "Recent Activity" section still shows dummy/placeholder data
- API endpoint `/api/teacher/recent-activity` exists and is refactored
- No errors in terminal logs
- API call may not be reaching the server

**Evidence:**
- User confirmed: "that user activity is not working"
- Terminal logs show no calls to `/api/teacher/recent-activity` endpoint
- Only `/api/teacher/courses` endpoints are being called

**Possible Causes:**
1. Frontend not making the API call (check useEffect dependencies)
2. API call failing silently (check browser console for errors)
3. Response not being processed correctly by frontend
4. State management issue (recentActivity state not updating)

**Next Steps:**
1. [ ] Check browser console (F12) for JavaScript errors
2. [ ] Verify teacher dashboard fetchTeacherData function is calling recent activity API
3. [ ] Add console.log debugging to teacher dashboard useEffect
4. [ ] Check if activityResponse.ok is false
5. [ ] Verify state update logic for recentActivity
6. [ ] Test with hard refresh (Cmd+Shift+R)

**Related Files:**
- `/app/teacher/dashboard/page.tsx` - Frontend implementation
- `/app/api/teacher/recent-activity/route.ts` - Backend API
- `/lib/services/enrollment/enrollment.repository.ts` - Data fetching

**Documentation:**
- See `/docs/FIRESTORE_INDEX_SETUP.md` for context

---

### **2. Lesson Management - Add/Edit/Delete Lessons** 🟡
**Priority:** P2 - Medium  
**Status:** Not Started

**Issue Description:**
- Course edit page shows lessons list but no management functions yet
- Teachers need ability to add new lessons to courses
- Teachers need ability to edit existing lesson content
- Teachers need ability to delete lessons
- Teachers need ability to reorder lessons

**Required API Endpoints:**
- [ ] POST `/api/courses/[courseId]/lessons` - Create new lesson
- [ ] PUT `/api/courses/[courseId]/lessons/[lessonId]` - Update lesson
- [ ] DELETE `/api/courses/[courseId]/lessons/[lessonId]` - Delete lesson
- [ ] PATCH `/api/courses/[courseId]/lessons/reorder` - Reorder lessons

**Related Files:**
- `/app/teacher/course/edit/[id]/page.tsx` - Frontend (has LessonModal component)
- `/components/teacher/lesson-modal.tsx` - Lesson creation modal
- `/lib/services/course/lesson.service.ts` - Business logic
- `/lib/services/course/lesson.repository.ts` - Firestore operations

---

### **3. Course Publishing Workflow** 🟡
**Priority:** P2 - Medium  
**Status:** Not Started

**Issue Description:**
- Courses have `isPublished` field but no toggle functionality
- Need UI button to publish/unpublish courses
- Published courses should appear in student course browse page
- Unpublished courses should only be visible to teacher

**Required Changes:**
- [ ] Add publish/unpublish button to teacher course edit page
- [ ] Create PATCH `/api/courses/[courseId]/publish` endpoint
- [ ] Update course browse page to filter by `isPublished: true`
- [ ] Add validation: can only publish courses with at least 1 lesson

**Related Files:**
- `/app/teacher/course/edit/[id]/page.tsx` - Add publish button
- `/app/courses/page.tsx` - Filter published courses

---

### **4. Course Browse & Enrollment** 🟡
**Priority:** P2 - Medium  
**Status:** Partially Complete

**Current State:**
- Enrollment service exists and works
- Student can manually enroll via API
- No UI for browsing available courses
- No "Enroll" button on course detail pages

**Required Changes:**
- [ ] Update `/app/courses/page.tsx` to show published courses
- [ ] Add course filtering (by level, language, teacher)
- [ ] Add "Enroll" button to course detail page
- [ ] Implement enrollment confirmation modal
- [ ] Handle already-enrolled state (show "Go to Course" instead)
- [ ] Add enrollment success toast notification

**Related Files:**
- `/app/courses/page.tsx` - Course browse page
- `/app/course/[id]/page.tsx` - Course detail page
- `/lib/services/enrollment/enrollment.service.ts` - Enrollment logic

---

### **5. Lesson Viewing & Progress Tracking** 🟢
**Priority:** P3 - Low  
**Status:** Not Started

**Issue Description:**
- Students can see enrolled courses but can't access lessons yet
- Need lesson viewer page for text/video/quiz lessons
- Need progress tracking (mark lesson as complete)
- Need quiz submission and scoring

**Required Components:**
- [ ] Lesson viewer page `/course/[courseId]/lesson/[lessonId]`
- [ ] Text lesson renderer
- [ ] Video lesson player
- [ ] Quiz lesson interface with answer submission
- [ ] Progress update on lesson completion
- [ ] Next lesson navigation

**Related Files:**
- Create: `/app/course/[courseId]/lesson/[lessonId]/page.tsx`
- `/lib/services/enrollment/enrollment.service.ts` - Update progress methods

---

### **6. Firestore Index Management** 🟢
**Priority:** P3 - Low  
**Status:** Resolved (1 index created)

**Current State:**
- ✅ `userId + enrolledAt` index created (for student enrollments)
- ⏳ `courseId + enrolledAt` index NOT needed (query refactored)

**Note:** The second index was avoided by refactoring the teacher recent activity query to use parallel per-course queries instead of a single `where...in` query.

---

## 📋 **Recommended Next Session Priorities**

**Immediate (This Session):**
1. 🔴 **Fix teacher recent activity display** - High impact, should be quick fix
2. 🟡 **Test course update functionality** - Verify PUT endpoint works after auth fix

**Short-term (Next 1-2 Sessions):**
3. 🟡 **Implement lesson management** - Core teacher functionality
4. 🟡 **Add course publish/unpublish** - Required for student course discovery
5. 🟡 **Build course browse UI** - Students need to find courses

**Medium-term (Next 3-5 Sessions):**
6. 🟢 **Lesson viewer & progress tracking** - Student learning experience
7. 🟢 **Quiz system** - Assessment functionality

---

## 🔗 **Related Documentation**

- [Firestore Index Setup](./FIRESTORE_INDEX_SETUP.md) - Index configuration and troubleshooting
- [Authentication Fix Summary](./AUTHENTICATION_FIX_SUMMARY.md) - Auth implementation details
- [Phase 3 Status & Testing](./PHASE_3_STATUS_AND_TESTING.md) - Testing guidelines
- [Debug System](./DEBUG_SYSTEM.md) - Logging and debugging tools

---

## 📅 **Timeline**

| Date | Completed Tasks |
|------|----------------|
| Oct 17, 2025 | Dashboard real data, Firestore index, course PUT/DELETE auth |
| *Pending* | Teacher recent activity fix |
| *Pending* | Lesson management |
| *Pending* | Course publishing |
| *Pending* | Course browse UI |

---

**Last Updated:** October 17, 2025  
**Document Owner:** J (ZenType Architect)  
**Next Review:** After teacher recent activity fix
