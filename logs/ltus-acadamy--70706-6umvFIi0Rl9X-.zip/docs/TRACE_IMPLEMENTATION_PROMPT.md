# Claude Code Terminal - Trace ID Implementation Prompt

**Date:** October 9, 2025  
**Task:** Implement Trace ID & Distributed Logging System  
**Branch:** `firebase-migration`  
**Architecture:** Service-isolated, conflict-free development

---

## 🎯 Mission Statement

Implement a complete **Trace ID & Distributed Logging System** for the DualLing platform following these guides:
1. `/docs/TRACE_ID_LOGGING_SYSTEM.md` (Primary implementation guide)
2. `/docs/TRACE_SYSTEM_SUMMARY.md` (Quick reference)
3. `/docs/SERVERLESS_ARCHITECTURE.md` (Service isolation principles)
4. `/.github/chatmodes/J-LTUS.chatmode.md` (Operational rules)

---

## 🔒 Non-Negotiable Rules (Prime Directives)

### **1. System Integrity (99% Certainty Rule)**
- Before committing ANY change, you must be 99% certain it won't break existing functionality
- Test each layer independently before moving to the next
- If ANY doubt exists, HALT and ask for clarification
- Existing DebugLogger must continue to work during and after implementation

### **2. IKB Protocol (Read-First, Write-Back)**
- **BEFORE CODING:** Read `/docs/MAIN.md` → Navigate to relevant docs
- **REQUIRED READING:**
  - `/docs/TRACE_ID_LOGGING_SYSTEM.md` (full implementation guide)
  - `/docs/SERVERLESS_ARCHITECTURE.md` (service isolation)
  - `/docs/DEBUG_SYSTEM.md` (existing debug infrastructure)
- **AFTER CODING:** Update `/docs/TRACE_ID_LOGGING_SYSTEM.md` with implementation notes
- **AFTER COMPLETION:** Update `/docs/MAIN.md` Recent Changes Log

### **3. Git Workflow**
- **Incremental Commits:** After each successful layer (NOT after every file)
- **Commit Format:** `feat: [Layer X] Brief description`
- **NO PUSH:** Do not push to remote until entire trace system is complete and verified
- **Branch:** Stay on `firebase-migration` branch

### **4. Verification Protocol**
- **No Assumptions:** Server starting ≠ feature working
- **User Validation Required:** After each phase, provide test steps
- **Wait for Confirmation:** Do not proceed to next phase until user verifies

---

## 📋 Implementation Phases (Execute in Order)

### **Phase 1: Foundation Layer (Week 1, Day 1-2)**

#### **1.1 Create Trace Context Interfaces**

**Location:** `lib/tracing/trace-context.ts`

**Requirements:**
- Define `TraceContext` interface (traceId, spanId, parentSpanId, userId, service, operation, startTime, metadata)
- Define `Span` interface (spanId, parentSpanId, service, operation, startTime, endTime, duration, status, error, metadata)
- Define `Trace` interface (traceId, userId, route, method, statusCode, spans, startTime, endTime, totalDuration, status)
- Export all interfaces
- Add JSDoc comments for each interface

**Verification Steps:**
```bash
# After creating this file:
1. Run: npm run build (should compile with no errors)
2. Check: TypeScript can import these types in other files
```

**Git Commit:**
```bash
git add lib/tracing/trace-context.ts
git commit -m "feat: [Layer 1] Add trace context interfaces and types"
```

---

#### **1.2 Create Trace Storage (AsyncLocalStorage)**

**Location:** `lib/tracing/trace-storage.ts`

**Requirements:**
- Import `AsyncLocalStorage` from `async_hooks`
- Create singleton `traceStorage` instance
- Implement `getTraceContext()` function
- Implement `createTraceContext()` function
- Implement `generateTraceId()` using `crypto.randomUUID()`
- Implement `generateSpanId()` using shortened UUID
- Add JSDoc comments

**Critical Notes:**
- AsyncLocalStorage is **Node.js ONLY** (server-side)
- This will NOT work in client components
- Mark file with `"use server"` if needed

**Verification Steps:**
```bash
# After creating this file:
1. Create test file: lib/tracing/__tests__/trace-storage.test.ts
2. Test trace context creation
3. Test UUID generation
4. Verify AsyncLocalStorage propagation
```

**Git Commit:**
```bash
git add lib/tracing/trace-storage.ts
git commit -m "feat: [Layer 1] Add trace storage with AsyncLocalStorage"
```

---

#### **1.3 Create Trace Logger (Enhanced DebugLogger Integration)**

**Location:** `lib/tracing/trace-logger.ts`

**Requirements:**
- Import existing `DebugLogger` from `@/lib/utils/debug-logger`
- Create `TraceLogger` class (NOT singleton - will be instantiated)
- Implement `log()` method that auto-injects trace context
- Implement `startSpan()` method
- Implement `endSpan()` method with duration calculation
- Implement `getTrace()` method
- Implement `clearOldTraces()` method for cleanup
- Store spans in `Map<string, Span[]>` keyed by traceId

**Critical Notes:**
- **DO NOT MODIFY** existing `lib/utils/debug-logger.ts`
- TraceLogger **wraps** DebugLogger, doesn't replace it
- All logs must still appear in existing DebugPanel

**Verification Steps:**
```bash
# After creating this file:
1. Start dev server: npm run dev
2. Open DebugPanel (Ctrl+Shift+D)
3. Manually call traceLogger methods in a test API route
4. Verify logs appear with traceId metadata
5. Verify existing logs still work
```

**Git Commit:**
```bash
git add lib/tracing/trace-logger.ts
git commit -m "feat: [Layer 1] Add trace logger with span tracking"
```

---

**🛑 CHECKPOINT 1: Phase 1 Verification**

Before proceeding, provide user with these test steps:

```markdown
## Phase 1 Verification Steps

1. **Check TypeScript Compilation:**
   ```bash
   npm run build
   # Should complete with NO errors
   ```

2. **Check File Structure:**
   ```bash
   ls -la lib/tracing/
   # Should show:
   # - trace-context.ts
   # - trace-storage.ts
   # - trace-logger.ts
   ```

3. **Test Trace Logger:**
   Create temporary test file `app/api/test-trace/route.ts`:
   ```typescript
   import { traceStorage, createTraceContext } from '@/lib/tracing/trace-storage';
   import { traceLogger } from '@/lib/tracing/trace-logger';
   
   export async function GET() {
     const context = createTraceContext({
       service: 'Test',
       operation: 'test-trace',
     });
     
     return traceStorage.run(context, () => {
       traceLogger.log('info', 'Test', 'Trace system test', { working: true });
       return Response.json({ success: true, traceId: context.traceId });
     });
   }
   ```
   
   Then:
   - Visit: http://localhost:3000/api/test-trace
   - Open DebugPanel (Ctrl+Shift+D)
   - Verify log appears with traceId in metadata
   - Delete test file after verification

**WAIT FOR USER CONFIRMATION BEFORE PROCEEDING TO PHASE 2**
```

---

### **Phase 2: Middleware Integration (Week 1, Day 3-4)**

#### **2.1 Create Tracing Middleware**

**Location:** `lib/middleware/tracing.middleware.ts`

**Requirements:**
- Import `NextRequest`, `NextResponse` from `next/server`
- Import trace storage functions
- Export `tracingMiddleware` function
- Extract or generate trace ID from `x-trace-id` header
- Extract user ID from auth headers (if available)
- Determine service from URL path
- Create trace context
- Log request start
- Add `x-trace-id` to response headers
- Return response wrapped in `traceStorage.run()`

**Helper Function:**
```typescript
function getServiceFromPath(pathname: string): string {
  if (pathname.startsWith('/api/auth')) return 'Auth';
  if (pathname.startsWith('/api/courses')) return 'Course';
  if (pathname.startsWith('/api/progress')) return 'Progress';
  if (pathname.startsWith('/api/enrollment')) return 'Enrollment';
  if (pathname.startsWith('/api/storage')) return 'Storage';
  return 'API';
}
```

**Verification Steps:**
```bash
# After creating this file:
1. Import in a test API route
2. Wrap handler with middleware
3. Check response headers contain x-trace-id
4. Verify trace context is available inside handler
```

**Git Commit:**
```bash
git add lib/middleware/tracing.middleware.ts
git commit -m "feat: [Layer 2] Add tracing middleware for request interception"
```

---

#### **2.2 Integrate Middleware Globally**

**Location:** `middleware.ts` (root level)

**Requirements:**
- Check if `middleware.ts` exists (if not, create it)
- Import `tracingMiddleware` from `@/lib/middleware/tracing.middleware`
- Add tracing logic to existing middleware (if any)
- Configure matcher to include all API routes
- **DO NOT BREAK** existing middleware functionality

**Example Structure:**
```typescript
import { NextRequest, NextResponse } from 'next/server';
import { tracingMiddleware } from '@/lib/middleware/tracing.middleware';

export function middleware(request: NextRequest) {
  // Apply tracing to all API routes
  if (request.nextUrl.pathname.startsWith('/api')) {
    return tracingMiddleware(request);
  }
  
  // Pass through other requests
  return NextResponse.next();
}

export const config = {
  matcher: [
    '/api/:path*',
    // Add other routes if needed
  ],
};
```

**Verification Steps:**
```bash
# After updating middleware.ts:
1. Restart dev server (required for middleware changes)
2. Make any API request (e.g., http://localhost:3000/api/test)
3. Check response headers for x-trace-id
4. Verify DebugPanel shows log with traceId
```

**Git Commit:**
```bash
git add middleware.ts
git commit -m "feat: [Layer 2] Integrate tracing middleware globally"
```

---

**🛑 CHECKPOINT 2: Phase 2 Verification**

Provide user with these test steps:

```markdown
## Phase 2 Verification Steps

1. **Restart Dev Server:**
   ```bash
   # Kill existing server (Ctrl+C)
   npm run dev
   ```

2. **Test Trace ID Propagation:**
   - Open browser DevTools (Network tab)
   - Navigate to any page that makes API calls
   - Check API response headers for `x-trace-id`
   - Verify it's a valid UUID

3. **Test DebugPanel Integration:**
   - Open DebugPanel (Ctrl+Shift+D)
   - Start recording
   - Trigger any API call (login, register, etc.)
   - Verify logs appear with `traceId` in metadata
   - Verify multiple logs from same request share same traceId

4. **Test Different Services:**
   - Call `/api/auth/*` → Should show service: "Auth"
   - Call `/api/courses/*` → Should show service: "Course"

**WAIT FOR USER CONFIRMATION BEFORE PROCEEDING TO PHASE 3**
```

---

### **Phase 3: Service Integration - AuthService (Week 1, Day 5 - Week 2, Day 1)**

#### **3.1 Update AuthService with Trace Logging**

**Location:** `lib/services/auth/auth.service.ts` (or wherever AuthService exists)

**Requirements:**
- Import `traceLogger` from `@/lib/tracing/trace-logger`
- Add trace logging to ALL methods:
  - `registerUser()`
  - `loginWithEmail()`
  - `loginWithGoogle()`
  - `logout()`
  - `resetPassword()`
  - `resendVerificationEmail()`
  - `getCurrentUser()`

**Pattern for Each Method:**
```typescript
async registerUser(email: string, password: string, name: string) {
  const spanId = traceLogger.startSpan('Auth', 'registerUser', { email: email.split('@')[1] }); // Only log domain

  try {
    // Step 1
    traceLogger.log('info', 'Auth', 'Creating Firebase Auth user');
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    traceLogger.log('success', 'Auth', 'Firebase user created', { uid: userCredential.user.uid });

    // Step 2
    traceLogger.log('info', 'Auth', 'Creating Firestore user document');
    await this.userRepo.create(userCredential.user.uid, { email, name, role: 'student' });
    traceLogger.log('success', 'Auth', 'Firestore document created');

    // Step 3
    traceLogger.log('info', 'Auth', 'Setting custom claims');
    await getAdminAuth().setCustomUserClaims(userCredential.user.uid, { role: 'student' });

    traceLogger.endSpan(spanId, 'success');
    return userCredential.user;
  } catch (error) {
    traceLogger.log('error', 'Auth', 'Registration failed', error);
    traceLogger.endSpan(spanId, 'error', {
      message: error instanceof Error ? error.message : 'Unknown error',
      stack: error instanceof Error ? error.stack : undefined,
    });
    throw error;
  }
}
```

**Critical Notes:**
- **NEVER log passwords** (plain or hashed)
- **NEVER log full email addresses** in production (only domain)
- **NEVER log auth tokens**
- Use conditional logging: `process.env.NODE_ENV === 'production' ? emailDomain : email`

**Verification Steps:**
```bash
# After updating AuthService:
1. Start DebugPanel recording
2. Register a new user via UI
3. Check DebugPanel for:
   - [SPAN START] registerUser
   - Multiple info logs showing steps
   - [SPAN END] registerUser with duration
   - All logs share same traceId
4. Verify registration still works correctly
```

**Git Commit:**
```bash
git add lib/services/auth/auth.service.ts
git commit -m "feat: [Layer 3] Add trace logging to AuthService"
```

---

#### **3.2 Update UserRepository with Trace Logging**

**Location:** `lib/services/auth/user.repository.ts` (or similar)

**Requirements:**
- Import `traceLogger`
- Add logs to CRUD operations:
  - `create()`
  - `getById()`
  - `getByEmail()`
  - `update()`
  - `delete()`

**Pattern:**
```typescript
async create(uid: string, data: UserData) {
  const spanId = traceLogger.startSpan('Firestore', 'users.create', { uid });
  
  try {
    traceLogger.log('info', 'Firestore', `Creating user document: ${uid}`);
    await this.collection.doc(uid).set(data);
    traceLogger.log('success', 'Firestore', 'User document created');
    traceLogger.endSpan(spanId, 'success');
  } catch (error) {
    traceLogger.log('error', 'Firestore', 'User creation failed', error);
    traceLogger.endSpan(spanId, 'error', {
      message: error instanceof Error ? error.message : 'Unknown error',
    });
    throw error;
  }
}
```

**Verification Steps:**
```bash
# After updating UserRepository:
1. Trigger any operation that uses UserRepository
2. Check DebugPanel for Firestore logs
3. Verify operation still works
```

**Git Commit:**
```bash
git add lib/services/auth/user.repository.ts
git commit -m "feat: [Layer 3] Add trace logging to UserRepository"
```

---

**🛑 CHECKPOINT 3: Phase 3 Verification**

Provide user with these test steps:

```markdown
## Phase 3 Verification Steps

1. **Test Complete Registration Flow:**
   - Open DebugPanel and start recording
   - Navigate to registration page
   - Fill out form and submit
   - Check DebugPanel for:
     ```
     [SPAN START] registerUser
     ├─ Firebase Auth user creation
     ├─ Firestore document creation
     └─ Custom claims set
     [SPAN END] registerUser (XXXms)
     ```
   - All logs should share SAME traceId

2. **Test Login Flow:**
   - Clear DebugPanel
   - Start recording
   - Login with registered user
   - Verify similar span structure
   - Check traceId consistency

3. **Test Error Handling:**
   - Try registering with existing email
   - Verify error is logged with traceId
   - Verify span ends with status: "error"

4. **Verify No Regression:**
   - Authentication should still work perfectly
   - No console errors
   - DebugPanel should still be functional

**WAIT FOR USER CONFIRMATION BEFORE PROCEEDING TO PHASE 4**
```

---

### **Phase 4: Additional Services (Week 2, Day 2-4)**

#### **4.1 CourseService (If Exists)**

**Location:** `lib/services/course/course.service.ts` (or similar)

**Apply Same Pattern:**
- Import `traceLogger`
- Add `startSpan()` and `endSpan()` to all methods
- Log key operations (create, update, publish, delete)
- Log Firestore operations
- Log any external API calls

**Git Commit:**
```bash
git add lib/services/course/course.service.ts
git commit -m "feat: [Layer 3] Add trace logging to CourseService"
```

---

#### **4.2 StorageService (If Exists)**

**Location:** `lib/services/storage/storage.service.ts` (or similar)

**Special Requirements:**
- Log upload start (filename, size)
- Log upload progress at 25%, 50%, 75%, 100%
- Log upload complete with URL
- **DO NOT** log every byte transferred
- Log download requests

**Git Commit:**
```bash
git add lib/services/storage/storage.service.ts
git commit -m "feat: [Layer 3] Add trace logging to StorageService"
```

---

#### **4.3 Other Services (As Needed)**

Apply trace logging to:
- `EnrollmentService`
- `ProgressService`
- Any other service classes

**Pattern:**
- Always use `startSpan()` and `endSpan()`
- Log key operations only
- Avoid logging sensitive data
- Keep logs actionable

---

**🛑 CHECKPOINT 4: Phase 4 Verification**

```markdown
## Phase 4 Verification Steps

1. **Test Each Service:**
   - Trigger operations for each updated service
   - Verify logs appear in DebugPanel
   - Verify spans are properly nested
   - Check duration calculations

2. **Test Cross-Service Flows:**
   - Example: Course enrollment (Auth → Course → Enrollment)
   - Verify all services share same traceId
   - Check span hierarchy

3. **Performance Check:**
   - Ensure trace logging doesn't slow down operations
   - Check for memory leaks (long-running sessions)

**WAIT FOR USER CONFIRMATION BEFORE PROCEEDING TO PHASE 5**
```

---

### **Phase 5: Production Integration (Week 2, Day 5 - Week 3)**

#### **5.1 Create GCP Logger Adapter**

**Location:** `lib/tracing/gcp-logger.ts`

**Requirements:**
- Create `GCPLogger` class
- Only enabled when `NODE_ENV === 'production'`
- Format logs according to GCP Cloud Logging structure:
  ```json
  {
    "severity": "INFO",
    "timestamp": "ISO8601",
    "trace": "projects/{projectId}/traces/{traceId}",
    "spanId": "string",
    "labels": { "service": "...", "operation": "..." },
    "message": "string",
    "jsonPayload": {}
  }
  ```
- Use `console.log(JSON.stringify(log))` for output
- Map log levels: debug→DEBUG, info→INFO, success→INFO, warn→WARNING, error→ERROR

**Git Commit:**
```bash
git add lib/tracing/gcp-logger.ts
git commit -m "feat: [Layer 4] Add GCP Cloud Logging adapter"
```

---

#### **5.2 Integrate GCP Logger into TraceLogger**

**Location:** `lib/tracing/trace-logger.ts`

**Requirements:**
- Import `GCPLogger`
- In production, send logs to BOTH DebugLogger (for dev) AND GCPLogger
- Use environment variable check: `process.env.NODE_ENV === 'production'`

**Git Commit:**
```bash
git add lib/tracing/trace-logger.ts
git commit -m "feat: [Layer 4] Integrate GCP logger for production"
```

---

#### **5.3 Update Documentation**

**Location:** `/docs/TRACE_ID_LOGGING_SYSTEM.md`

**Requirements:**
- Add "Implementation Complete" section
- Document any deviations from original plan
- Add troubleshooting section with common issues
- Update examples with actual code from implementation

**Location:** `/docs/MAIN.md`

**Requirements:**
- Update Recent Changes Log:
  ```markdown
  ### October 9, 2025 - Phase 2: Trace System Implementation
  - **[COMPLETE]** Implemented Trace ID & Distributed Logging System
  - **[CODE]** Created trace context, storage, and logger (Layers 1-3)
  - **[CODE]** Integrated tracing middleware globally
  - **[CODE]** Updated AuthService with trace logging
  - **[CODE]** Updated [list other services] with trace logging
  - **[CODE]** Added GCP Cloud Logging adapter for production
  - **[TESTED]** Verified trace propagation across services
  - **[DOCS]** Updated implementation documentation
  ```

**Git Commit:**
```bash
git add docs/TRACE_ID_LOGGING_SYSTEM.md docs/MAIN.md
git commit -m "docs: Update trace system documentation with implementation notes"
```

---

**🛑 FINAL CHECKPOINT: Complete System Verification**

```markdown
## Final System Verification

1. **Full Stack Test:**
   - Open DebugPanel
   - Start recording
   - Perform complete user journey:
     * Register new account
     * Login
     * Browse courses
     * Enroll in course
     * Upload file (if applicable)
     * Logout
   - Verify ALL logs share appropriate traceIds
   - Verify spans are properly nested
   - Check for any console errors

2. **Performance Test:**
   - Test with DebugPanel closed (no performance impact)
   - Test with DebugPanel open (acceptable impact)
   - Check memory usage (no leaks)

3. **Production Readiness:**
   - Set `NODE_ENV=production` locally
   - Test GCP log format output
   - Verify no PII is logged
   - Verify sensitive data is excluded

4. **Regression Test:**
   - All existing features still work
   - DebugPanel still functional
   - Authentication works
   - API routes respond correctly

**IF ALL TESTS PASS:**
- Create final commit: `feat: Complete Trace ID system implementation`
- Push to remote: `git push origin firebase-migration`
- Update ACTION_PLAN.md status to COMPLETE
```

---

## 🏗️ Conflict-Free Development Guidelines

### **Service Isolation Checklist**

For each service you update, ensure:

- [ ] **No cross-service imports** (except interfaces/types)
- [ ] **Independent logging** (each service logs its own operations)
- [ ] **No shared mutable state** (trace context via AsyncLocalStorage)
- [ ] **Clear boundaries** (Service → Repository → Firestore)

### **Parallel Development Safety**

If multiple devs work on different services:

```
Dev A: Updates AuthService
  ├─ lib/services/auth/auth.service.ts
  ├─ lib/services/auth/user.repository.ts
  └─ Only touches Auth-related files

Dev B: Updates CourseService
  ├─ lib/services/course/course.service.ts
  ├─ lib/services/course/course.repository.ts
  └─ Only touches Course-related files

Shared Files (Careful Coordination):
  ├─ lib/tracing/trace-logger.ts (created once, rarely modified)
  ├─ middleware.ts (coordinate changes)
  └─ docs/MAIN.md (coordinate updates)

MERGE: ✅ NO CONFLICTS (different files)
```

### **Merge Conflict Prevention**

- **Additive Changes Only:** When updating shared files (like types), only ADD, don't modify existing
- **Communicate:** If two devs need same file, one waits or coordinates
- **Small Commits:** Frequent, small commits reduce conflict window
- **Pull Often:** `git pull origin firebase-migration` before starting work

---

## 🔒 Security Compliance Checklist

For EVERY log statement, verify:

- [ ] **No passwords** (plain, hashed, or encrypted)
- [ ] **No API keys** (Firebase, third-party, etc.)
- [ ] **No auth tokens** (JWT, Firebase ID tokens, refresh tokens)
- [ ] **No credit card numbers** (obvious)
- [ ] **Email domains only in production** (not full emails)
- [ ] **User IDs only** (not full user objects)
- [ ] **No IP addresses** (without GDPR consent)
- [ ] **Sanitized error messages** (no sensitive data in stack traces)

---

## 🧪 Testing Strategy

### **Unit Tests** (Optional but Recommended)

Create test files:
```
lib/tracing/__tests__/
├── trace-storage.test.ts
├── trace-logger.test.ts
└── trace-context.test.ts
```

Test:
- Trace ID generation (unique)
- Span duration calculation (accurate)
- Context propagation (AsyncLocalStorage)
- Error handling (graceful failures)

### **Integration Tests**

Test:
- Full request flow (Frontend → API → Service → Repository)
- Multiple services in one request
- Error scenarios (network failures, auth errors)
- Concurrent requests (different traceIds)

---

## 📊 Success Metrics

After implementation, measure:

1. **Coverage:** % of services with trace logging
2. **Performance:** Overhead <5ms per request
3. **Memory:** No leaks after 1000 requests
4. **Completeness:** All logs have traceId
5. **Usability:** Can debug issues using traceId in <2 minutes

---

## 🎯 Deliverables Checklist

Before marking as COMPLETE:

- [ ] All 5 layers implemented (Context, Storage, Logger, Middleware, Service)
- [ ] At least 3 services have trace logging (Auth, Course, Storage)
- [ ] DebugPanel shows traces correctly
- [ ] No regressions (all existing features work)
- [ ] Documentation updated (implementation notes)
- [ ] Git history clean (meaningful commits)
- [ ] User verification complete (all checkpoints passed)
- [ ] Production adapter ready (GCP logger)
- [ ] Security review passed (no PII logged)

---

## 🚨 Emergency Rollback Plan

If something goes catastrophically wrong:

1. **Immediate Rollback:**
   ```bash
   git reset --hard HEAD~[number of commits]
   git push origin firebase-migration --force
   ```

2. **Partial Rollback (Remove Tracing Middleware):**
   ```typescript
   // In middleware.ts, comment out tracing:
   export function middleware(request: NextRequest) {
     // return tracingMiddleware(request); // DISABLED
     return NextResponse.next();
   }
   ```

3. **Keep Infrastructure, Disable Logging:**
   ```typescript
   // In lib/tracing/trace-logger.ts
   private enabled = false; // Set to false
   ```

---

## 📞 When to Ask for Help

STOP and ask user if:

- ❌ TypeScript compilation fails with trace-related errors
- ❌ Existing DebugPanel stops working
- ❌ AsyncLocalStorage doesn't propagate context
- ❌ Middleware breaks existing API routes
- ❌ Performance degrades significantly (>10ms overhead)
- ❌ Memory usage increases dramatically
- ❌ Any uncertainty about service boundaries
- ❌ Unsure if data is PII or sensitive

---

## 🎓 Key Implementation Insights

### **AsyncLocalStorage Magic**

```typescript
// This is why we use AsyncLocalStorage:
traceStorage.run(context, async () => {
  await serviceA(); // Has access to context
  await serviceB(); // Also has access to SAME context
  await serviceC(); // Also has access to SAME context
  // All without passing context as parameter!
});
```

### **Span Hierarchy**

```typescript
// Trace abc123
├─ Span a1b2 (Auth.registerUser) - 368ms
│  ├─ Span c3d4 (Firebase.createUser) - 245ms
│  ├─ Span e5f6 (Firestore.createDocument) - 89ms
│  └─ Span g7h8 (Auth.setClaims) - 34ms
```

### **DebugPanel Integration**

```typescript
// TraceLogger calls DebugLogger under the hood:
traceLogger.log('info', 'Auth', 'User created');
  ↓
debugLogger.info('Auth', 'User created', { traceId: 'abc123' });
  ↓
DebugPanel shows log with traceId metadata
```

---

## 🔗 Essential Links

- **Primary Guide:** `/docs/TRACE_ID_LOGGING_SYSTEM.md`
- **Quick Reference:** `/docs/TRACE_SYSTEM_SUMMARY.md`
- **Architecture:** `/docs/SERVERLESS_ARCHITECTURE.md`
- **Operational Rules:** `/.github/chatmodes/J-LTUS.chatmode.md`
- **Current Status:** `/docs/ACTION_PLAN.md`

---

## ✅ Final Output Format

After COMPLETE implementation, provide:

```markdown
# Trace ID System - Implementation Report

## Summary
- ✅ All 5 layers implemented
- ✅ [X] services updated with trace logging
- ✅ DebugPanel integration working
- ✅ No regressions detected
- ✅ Documentation updated

## Files Created
- lib/tracing/trace-context.ts
- lib/tracing/trace-storage.ts
- lib/tracing/trace-logger.ts
- lib/middleware/tracing.middleware.ts
- lib/tracing/gcp-logger.ts

## Files Modified
- middleware.ts
- lib/services/auth/auth.service.ts
- lib/services/auth/user.repository.ts
- [list other modified files]
- docs/TRACE_ID_LOGGING_SYSTEM.md
- docs/MAIN.md

## Git Commits
- feat: [Layer 1] Add trace context interfaces and types
- feat: [Layer 1] Add trace storage with AsyncLocalStorage
- feat: [Layer 1] Add trace logger with span tracking
- [list all commits]

## Verification Results
- ✅ Registration flow traced successfully
- ✅ Login flow traced successfully
- ✅ Error scenarios handled correctly
- ✅ Performance overhead: [X]ms average
- ✅ Memory usage: stable

## Next Steps
1. Push to remote: git push origin firebase-migration
2. Update ACTION_PLAN.md: Mark Phase 2 COMPLETE
3. Begin Phase 3: API Routes Refactoring
```

---

**Ready to begin implementation?**

Execute phases **sequentially**, wait for user verification at each checkpoint, and maintain 99% certainty before each commit.

Good luck! 🚀
