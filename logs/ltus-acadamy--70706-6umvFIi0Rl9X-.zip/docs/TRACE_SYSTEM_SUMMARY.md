# Trace ID System - Implementation Summary

**Created:** October 9, 2025  
**Status:** Ready for Implementation  
**Phase:** Phase 2 - Foundation Architecture

---

## ✅ What We Just Created

### **1. Complete Trace ID Architecture Guide** 
📄 **Location:** `/docs/TRACE_ID_LOGGING_SYSTEM.md`

**Key Features:**
- ✅ **Service-isolated logging** - Auth logs don't interfere with Storage logs
- ✅ **Development-first** - Integrates with your existing DebugPanel
- ✅ **GCP-ready** - Structured logs for Cloud Logging in production
- ✅ **Conflict-free** - Each service has independent logging patterns
- ✅ **Zero noise** - Only logs what's actually useful for debugging

---

## 🎯 Decision: Trace ID vs Correlation ID

**Your System Analysis:**
- **4-8 services** (Next.js, Firebase Auth, Firestore, Storage)
- **Branching request flows** (Frontend → API → Multiple Firebase calls)
- **Minimal async** (no complex workflows yet)
- **Direct migration** (no existing users)

**Recommendation: START WITH TRACE ID ONLY** ✅

**Why:**
- Simple request-response flows = Trace ID is sufficient
- No complex async workflows yet = Don't need Correlation ID
- Can add Correlation ID later in Phase 4+ when async complexity increases
- Avoid over-engineering for current needs

---

## 🏗️ Architecture Overview

```
Frontend Request
    ↓ (generates traceId: abc123)
Next.js API Route
    ↓ (creates trace context with traceId)
AuthService.registerUser()
    ↓ (starts span: "registerUser")
    ├─ Firebase Auth call (span: "createUser", 245ms)
    ├─ Firestore write (span: "createDocument", 89ms)
    └─ Set custom claims (span: "setClaims", 34ms)
    ↓ (ends span: total 368ms)
Response with x-trace-id header
```

**All logs share the SAME traceId = Easy debugging!**

---

## 📊 What Gets Logged (Smart Filtering)

### ✅ **DO Log:**
- Authentication flows (login, register, logout)
- API request lifecycle (start, end, duration)
- Firestore operations (read, write, query) with durations
- Storage operations (upload progress, completion)
- Errors at all levels (with stack traces)
- Slow operations (>1 second)

### ❌ **DON'T Log:**
- Every component render (too chatty)
- Individual Firestore reads in large queries (only aggregates)
- Routine health checks (unless they fail)
- Client-side analytics (use Firebase Analytics)
- Sensitive data (passwords, tokens, PII)

---

## 🛠️ Implementation Layers

### **Layer 1: Trace Context** ✅ Designed
```typescript
// Interfaces for TraceContext, Span, Trace
// Located: lib/tracing/trace-context.ts
```

### **Layer 2: Trace Storage** ✅ Designed
```typescript
// AsyncLocalStorage for automatic context propagation
// Located: lib/tracing/trace-storage.ts
```

### **Layer 3: Trace Logger** ✅ Designed
```typescript
// Enhanced logger with span tracking
// Located: lib/tracing/trace-logger.ts
// Integrates with existing DebugLogger
```

### **Layer 4: Middleware** ✅ Designed
```typescript
// Automatic trace context injection for all API requests
// Located: lib/middleware/tracing.middleware.ts
```

### **Layer 5: Service Integration** ✅ Pattern Defined
```typescript
// Example: AuthService with trace logging
// Pattern applies to ALL services (Auth, Course, Storage, etc.)
```

---

## 🎨 DebugPanel Integration

**New Feature: Trace View Tab**

```
┌────────────────────────────────────────────┐
│ [Logs] [Traces] [Auth] [Firestore] [API]  │
├────────────────────────────────────────────┤
│ Trace: abc123 (402ms)                      │
│                                            │
│ ┌─ Auth ─────────────■■■■■─────── 245ms  │
│ ┌─ Firestore ───■■─────────────── 89ms   │
│ ┌─ Auth ────■─────────────────── 34ms    │
│                                            │
│ Waterfall visualization of spans          │
└────────────────────────────────────────────┘
```

---

## 📋 Implementation Checklist

### **Phase 1: Foundation** (Week 1)
- [ ] Create trace context interfaces
- [ ] Implement AsyncLocalStorage wrapper
- [ ] Build trace logger with span tracking
- [ ] Test context propagation

### **Phase 2: Middleware** (Week 1-2)
- [ ] Create tracing middleware
- [ ] Add to global middleware chain
- [ ] Test trace ID generation
- [ ] Verify header propagation

### **Phase 3: AuthService** (Week 2)
- [ ] Update AuthService with trace logging
- [ ] Test registration flow with traces
- [ ] Verify spans in DebugPanel
- [ ] Check GCP-compatible log format

### **Phase 4: Other Services** (Week 2-3)
- [ ] Course Service
- [ ] Firestore Repository
- [ ] Storage Service
- [ ] Progress Service

### **Phase 5: Production** (Week 3)
- [ ] GCP Cloud Logging adapter
- [ ] Structured log format
- [ ] Alert policies
- [ ] Cost monitoring

---

## 🎯 Service-Specific Patterns

### **Auth Service**
```typescript
✅ Log: Login attempt (email domain only)
✅ Log: Firebase Auth duration
✅ Log: Firestore user fetch
✅ Log: Custom claims set
❌ Don't log: Passwords, tokens
```

### **Firestore Service**
```typescript
✅ Log: Query with filters and duration
✅ Log: Document count returned
✅ Log: Write operations
❌ Don't log: Every individual read
```

### **Storage Service**
```typescript
✅ Log: Upload start/progress/complete
✅ Log: File size and type
✅ Log: Download requests
❌ Don't log: Byte-level transfers
```

---

## 🔒 Security First

**PII Protection:**
```typescript
// ✅ GOOD: Log domain only
traceLogger.log('info', 'Auth', 'Registration', { 
  emailDomain: 'gmail.com' 
});

// ❌ BAD: Log full email
traceLogger.log('info', 'Auth', 'Registration', { 
  email: 'user@example.com' // PII!
});
```

**Sensitive Data Exclusion:**
- ❌ Passwords (plain or hashed)
- ❌ API keys
- ❌ Auth tokens
- ❌ Credit card numbers
- ❌ Full email in production
- ❌ User IP without consent

---

## ☁️ GCP Cloud Logging Format

**Structured Log Example:**
```json
{
  "severity": "INFO",
  "timestamp": "2025-10-09T12:34:56.789Z",
  "trace": "projects/paji-duolingo/traces/abc123",
  "spanId": "a1b2c3d4",
  "labels": {
    "service": "Auth",
    "operation": "registerUser",
    "userId": "xyz789"
  },
  "message": "User registered successfully",
  "jsonPayload": {
    "emailDomain": "gmail.com",
    "role": "student",
    "duration": 245
  }
}
```

**GCP Query Example:**
```sql
-- Find slow requests (>1 second)
SELECT timestamp, jsonPayload.traceId, labels.operation, jsonPayload.duration
FROM `paji-duolingo.logs`
WHERE jsonPayload.duration > 1000
  AND timestamp > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 1 DAY)
ORDER BY jsonPayload.duration DESC
```

---

## 🚀 Quick Start

### **Step 1: Read the Full Guide**
📄 `/docs/TRACE_ID_LOGGING_SYSTEM.md`

### **Step 2: Implement Foundation (Week 1)**
```bash
# Create trace context
touch lib/tracing/trace-context.ts
touch lib/tracing/trace-storage.ts
touch lib/tracing/trace-logger.ts
```

### **Step 3: Test with AuthService**
```typescript
// Add trace logging to AuthService.registerUser()
const spanId = traceLogger.startSpan('Auth', 'registerUser');
// ... do work ...
traceLogger.endSpan(spanId, 'success');
```

### **Step 4: Verify in DebugPanel**
- Start recording in DebugPanel
- Register a new user
- Check logs for traceId
- Verify all operations share same traceId

---

## 📈 Where We Are in the Project

**Phase 2: Authentication Migration** 🟡 IN PROGRESS

```
✅ Phase 1: Firebase Setup (COMPLETE)
    ├─ Firebase CLI configured
    ├─ Firestore & Storage enabled
    ├─ Debug System implemented
    └─ Service layer created

🟡 Phase 2: Trace System + Auth (IN PROGRESS)
    ├─ Trace ID architecture designed ✅
    ├─ Implementation guide created ✅
    ├─ Ready to implement trace infrastructure ⏳
    └─ Then: Refactor API routes ⏳

⏳ Phase 3: Data Migration (NEXT)
⏳ Phase 4: Frontend Integration
⏳ Phase 5: Production Launch
```

---

## 🎓 Key Takeaways

1. **Trace ID = Request Thread** - Connects all logs for one user action
2. **Service Isolation** - Each service logs independently (Auth, Firestore, Storage)
3. **Development First** - Integrated with DebugPanel for real-time visibility
4. **Production Ready** - GCP Cloud Logging format from day one
5. **Zero Noise** - Only log what's useful for debugging
6. **Security Built-in** - PII and sensitive data exclusion patterns

---

## 🔗 Related Documents

- [Main IKB](./MAIN.md) - Entry point to all documentation
- [Trace ID System (Full Guide)](./TRACE_ID_LOGGING_SYSTEM.md) - Complete implementation guide
- [Debug System](./DEBUG_SYSTEM.md) - Existing debug infrastructure
- [Serverless Architecture](./SERVERLESS_ARCHITECTURE.md) - Service isolation principles
- [Action Plan](./ACTION_PLAN.md) - Current tasks and status

---

## ✅ Next Actions

1. **Review the full guide** (`TRACE_ID_LOGGING_SYSTEM.md`)
2. **Approve the architecture** (or suggest changes)
3. **Start implementation** (follow Phase 1 checklist)
4. **Test with AuthService** (first use case)
5. **Expand to other services** (Course, Storage, etc.)

---

**Ready to proceed?** Let me know if you want to:
- Start implementing the trace system
- Make any changes to the architecture
- Clarify any concepts
- Add more service-specific patterns

---

**Document Owner:** ZenType Architect (J)  
**Status:** Architecture complete, awaiting implementation approval  
**Estimated Implementation:** 2-3 weeks (can be done in parallel with API refactoring)
