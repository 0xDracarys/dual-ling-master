/**
 * Debug Logger Utility
 * 
 * Singleton logger for the Debug Panel system.
 * Provides centralized logging with categories, levels, and persistence.
 * 
 * @example
 * const logger = DebugLogger.getInstance();
 * logger.info('Auth', 'User logged in', { uid: '123', email: 'user@example.com' });
 */

export type LogLevel = 'debug' | 'info' | 'success' | 'warn' | 'error';
export type LogCategory = 
  | 'Auth' 
  | 'Firestore' 
  | 'Storage' 
  | 'API' 
  | 'UI' 
  | 'Performance' 
  | 'Error'
  | string; // Allow custom categories

export interface DebugLog {
  id: string;
  timestamp: number;
  level: LogLevel;
  category: LogCategory;
  message: string;
  metadata?: any;
  stack?: string;
}

export interface DebugLoggerConfig {
  enabled: boolean;
  maxLogs: number;
  persistLogs: boolean;
  logToConsole: boolean;
  minLevel?: LogLevel;
}

const DEFAULT_CONFIG: DebugLoggerConfig = {
  enabled: process.env.NODE_ENV === 'development' || process.env.NEXT_PUBLIC_ENABLE_DEBUG === 'true',
  maxLogs: 1000,
  persistLogs: true,
  logToConsole: true,
  minLevel: 'debug',
};

const LOG_LEVEL_PRIORITY: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  success: 2,
  warn: 3,
  error: 4,
};

const LOG_LEVEL_COLORS: Record<LogLevel, string> = {
  debug: '#6B7280',  // gray
  info: '#3B82F6',   // blue
  success: '#10B981', // green
  warn: '#F59E0B',   // amber
  error: '#EF4444',  // red
};

const LOG_LEVEL_ICONS: Record<LogLevel, string> = {
  debug: '🐛',
  info: 'ℹ️',
  success: '✅',
  warn: '⚠️',
  error: '❌',
};

export class DebugLogger {
  private static instance: DebugLogger;
  private logs: DebugLog[] = [];
  private config: DebugLoggerConfig;
  private listeners: Set<(logs: DebugLog[]) => void> = new Set();
  private storageKey = 'debug-logs';

  private constructor(config: Partial<DebugLoggerConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.loadLogsFromStorage();
  }

  static getInstance(config?: Partial<DebugLoggerConfig>): DebugLogger {
    if (!DebugLogger.instance) {
      DebugLogger.instance = new DebugLogger(config);
    }
    return DebugLogger.instance;
  }

  /**
   * Configure the logger
   */
  configure(config: Partial<DebugLoggerConfig>): void {
    this.config = { ...this.config, ...config };
  }

  /**
   * Log a debug message (dev only)
   */
  debug(category: LogCategory, message: string, metadata?: any): void {
    this.log('debug', category, message, metadata);
  }

  /**
   * Log an informational message
   */
  info(category: LogCategory, message: string, metadata?: any): void {
    this.log('info', category, message, metadata);
  }

  /**
   * Log a success message
   */
  success(category: LogCategory, message: string, metadata?: any): void {
    this.log('success', category, message, metadata);
  }

  /**
   * Log a warning message
   */
  warn(category: LogCategory, message: string, metadata?: any): void {
    this.log('warn', category, message, metadata);
  }

  /**
   * Log an error message
   */
  error(category: LogCategory, message: string, error?: any): void {
    const metadata = error instanceof Error 
      ? { error: error.message, name: error.name }
      : error;
    
    const stack = error instanceof Error ? error.stack : undefined;
    
    this.log('error', category, message, metadata, stack);
  }

  /**
   * Core logging function
   */
  private log(
    level: LogLevel, 
    category: LogCategory, 
    message: string, 
    metadata?: any,
    stack?: string
  ): void {
    if (!this.config.enabled) return;

    // Check minimum log level
    if (this.config.minLevel && LOG_LEVEL_PRIORITY[level] < LOG_LEVEL_PRIORITY[this.config.minLevel]) {
      return;
    }

    const logEntry: DebugLog = {
      id: this.generateId(),
      timestamp: Date.now(),
      level,
      category,
      message,
      metadata,
      stack,
    };

    // Add to logs array
    this.logs.push(logEntry);

    // Enforce max logs limit
    if (this.logs.length > this.config.maxLogs) {
      this.logs.shift();
    }

    // Persist to localStorage
    if (this.config.persistLogs) {
      this.saveLogsToStorage();
    }

    // Log to console
    if (this.config.logToConsole) {
      this.logToConsole(logEntry);
    }

    // Notify listeners
    this.notifyListeners();
  }

  /**
   * Log to browser console with formatting
   */
  private logToConsole(log: DebugLog): void {
    const icon = LOG_LEVEL_ICONS[log.level];
    const color = LOG_LEVEL_COLORS[log.level];
    const timestamp = new Date(log.timestamp).toLocaleTimeString();
    
    const consoleMethod = log.level === 'error' ? 'error' : 
                          log.level === 'warn' ? 'warn' : 
                          'log';

    console[consoleMethod](
      `%c${icon} ${timestamp} [${log.category}]%c ${log.message}`,
      `color: ${color}; font-weight: bold;`,
      'color: inherit;',
      log.metadata || ''
    );

    if (log.stack) {
      console.error(log.stack);
    }
  }

  /**
   * Get all logs
   */
  getLogs(): DebugLog[] {
    return [...this.logs];
  }

  /**
   * Get logs by category
   */
  getLogsByCategory(category: LogCategory): DebugLog[] {
    return this.logs.filter(log => log.category === category);
  }

  /**
   * Get logs by level
   */
  getLogsByLevel(level: LogLevel): DebugLog[] {
    return this.logs.filter(log => log.level === level);
  }

  /**
   * Search logs
   */
  searchLogs(query: string): DebugLog[] {
    const lowerQuery = query.toLowerCase();
    return this.logs.filter(log => 
      log.message.toLowerCase().includes(lowerQuery) ||
      log.category.toLowerCase().includes(lowerQuery) ||
      JSON.stringify(log.metadata).toLowerCase().includes(lowerQuery)
    );
  }

  /**
   * Clear all logs
   */
  clearLogs(): void {
    this.logs = [];
    this.saveLogsToStorage();
    this.notifyListeners();
  }

  /**
   * Export logs as JSON
   */
  exportLogsAsJSON(): string {
    return JSON.stringify(this.logs, null, 2);
  }

  /**
   * Export logs as CSV
   */
  exportLogsAsCSV(): string {
    const headers = ['Timestamp', 'Level', 'Category', 'Message', 'Metadata'];
    const rows = this.logs.map(log => [
      new Date(log.timestamp).toISOString(),
      log.level,
      log.category,
      log.message,
      JSON.stringify(log.metadata || {}),
    ]);

    return [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');
  }

  /**
   * Download logs
   */
  downloadLogs(format: 'json' | 'csv' = 'json'): void {
    const content = format === 'json' ? this.exportLogsAsJSON() : this.exportLogsAsCSV();
    const blob = new Blob([content], { type: format === 'json' ? 'application/json' : 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `debug-logs-${Date.now()}.${format}`;
    a.click();
    URL.revokeObjectURL(url);
  }

  /**
   * Subscribe to log updates
   */
  subscribe(callback: (logs: DebugLog[]) => void): () => void {
    this.listeners.add(callback);
    // Return unsubscribe function
    return () => {
      this.listeners.delete(callback);
    };
  }

  /**
   * Notify all listeners
   */
  private notifyListeners(): void {
    this.listeners.forEach(callback => callback(this.getLogs()));
  }

  /**
   * Save logs to localStorage
   */
  private saveLogsToStorage(): void {
    if (typeof window === 'undefined') return;

    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.logs));
    } catch (error) {
      console.error('Failed to save logs to localStorage:', error);
    }
  }

  /**
   * Load logs from localStorage
   */
  private loadLogsFromStorage(): void {
    if (typeof window === 'undefined') return;

    try {
      const stored = localStorage.getItem(this.storageKey);
      if (stored) {
        this.logs = JSON.parse(stored);
      }
    } catch (error) {
      console.error('Failed to load logs from localStorage:', error);
    }
  }

  /**
   * Generate unique log ID
   */
  private generateId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Get logger statistics
   */
  getStats(): {
    total: number;
    byLevel: Record<LogLevel, number>;
    byCategory: Record<string, number>;
  } {
    const byLevel: Record<LogLevel, number> = {
      debug: 0,
      info: 0,
      success: 0,
      warn: 0,
      error: 0,
    };

    const byCategory: Record<string, number> = {};

    this.logs.forEach(log => {
      byLevel[log.level]++;
      byCategory[log.category] = (byCategory[log.category] || 0) + 1;
    });

    return {
      total: this.logs.length,
      byLevel,
      byCategory,
    };
  }
}

// Export singleton instance for convenience
export const logger = DebugLogger.getInstance();
