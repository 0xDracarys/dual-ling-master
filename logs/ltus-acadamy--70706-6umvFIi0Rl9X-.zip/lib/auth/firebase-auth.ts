import type { NextRequest } from 'next/server'
import { getAdminAuth } from '@/lib/firebase/admin'
import { connectDB } from '@/lib/mongodb'
import { UserModel } from '@/lib/models/User'

export interface FirebaseUserContext {
  uid: string
  email: string | null
  role: 'student' | 'teacher' | 'admin'
  claims: Record<string, unknown>
}

export async function verifyFirebaseIdToken(idToken: string) {
  const adminAuth = getAdminAuth()
  return adminAuth.verifyIdToken(idToken, true)
}

export function getBearerToken(request: NextRequest): string | null {
  const authHeader = request.headers.get('authorization')
  if (authHeader && authHeader.startsWith('Bearer ')) {
    return authHeader.substring(7)
  }
  return null
}

/**
 * Authenticate request using Firebase ID token.
 * Role resolution strategy:
 * 1) Use custom claims (role) if present
 * 2) Fallback to MongoDB user by email (preferred for existing data)
 */
export async function authenticateFirebaseRequest(request: NextRequest): Promise<FirebaseUserContext | null> {
  const token = getBearerToken(request)
  if (!token) return null

  const decoded = await verifyFirebaseIdToken(token)
  const claims = decoded as unknown as Record<string, unknown>

  let role = (claims.role as FirebaseUserContext['role']) || 'student'
  let email = decoded.email ?? null

  // Fallback: check MongoDB for role based on email
  if (!claims.role && email) {
    await connectDB()
    const user = await UserModel.findOne({ email: email.toLowerCase(), isActive: true })
    if (user) {
      role = user.role
    }
  }

  return {
    uid: decoded.uid,
    email,
    role,
    claims,
  }
}

/**
 * Set or update Firebase custom role claim for a user
 */
export async function setFirebaseUserRole(uid: string, role: 'student' | 'teacher' | 'admin') {
  const adminAuth = getAdminAuth()
  await adminAuth.setCustomUserClaims(uid, { role })
}
