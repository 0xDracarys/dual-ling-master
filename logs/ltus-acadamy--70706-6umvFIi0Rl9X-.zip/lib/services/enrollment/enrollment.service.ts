/**
 * Enrollment Service
 * Business logic for course enrollments
 * Phase 3: Course & Enrollment Services - Week 2
 */

import { traceLogger } from '@/lib/tracing/trace-logger';
import { EnrollmentRepository } from './enrollment.repository';
import { CourseRepository } from '../course/course.repository';
import type { Enrollment } from '@/lib/types/course.types';

export class EnrollmentService {
  private enrollmentRepo = new EnrollmentRepository();
  private courseRepo = new CourseRepository();

  /**
   * Enroll a student in a course
   */
  async enrollStudent(
    userId: string,
    courseId: string,
    userName: string,
    userEmail: string
  ): Promise<Enrollment> {
    const spanId = traceLogger.startSpan('Enrollment', 'enrollStudent', {
      userId,
      courseId,
    });

    try {
      traceLogger.log('info', 'Enrollment', 'Starting enrollment process');

      // Check if course exists and is published
      traceLogger.log('info', 'Enrollment', 'Verifying course exists and is published');
      const course = await this.courseRepo.getById(courseId);

      if (!course.isPublished) {
        throw new Error('Cannot enroll in unpublished course');
      }

      // Check if course is paid (future payment check here)
      if (course.isPaid) {
        traceLogger.log('warn', 'Enrollment', 'Attempted enrollment in paid course without payment');
        throw new Error('This course requires payment. Please complete checkout first.');
      }

      // Check if already enrolled
      traceLogger.log('info', 'Enrollment', 'Checking existing enrollment');
      const existingEnrollment = await this.enrollmentRepo.getByUserAndCourse(userId, courseId);

      if (existingEnrollment) {
        if (existingEnrollment.status === 'dropped') {
          // Re-enroll dropped student
          traceLogger.log('info', 'Enrollment', 'Re-enrolling previously dropped student');
          await this.enrollmentRepo.update(existingEnrollment.id, {
            status: 'active',
            enrolledAt: new Date() as any,
            lastAccessedAt: new Date() as any,
          });

          traceLogger.log('success', 'Enrollment', 'Student re-enrolled successfully');
          traceLogger.endSpan(spanId, 'success');

          return await this.enrollmentRepo.getById(existingEnrollment.id);
        }

        throw new Error('Already enrolled in this course');
      }

      // Create enrollment
      traceLogger.log('info', 'Enrollment', 'Creating enrollment document');
      const enrollment = await this.enrollmentRepo.create({
        userId,
        courseId,
        userName,
        userEmail,
        courseTitle: course.title,
        teacherName: course.teacherName,
        totalLessonsCount: course.lessonsCount,
      });

      // Increment course enrollment count
      traceLogger.log('info', 'Enrollment', 'Incrementing course enrollment count');
      await this.courseRepo.incrementEnrollmentCount(courseId);

      traceLogger.log('success', 'Enrollment', 'Student enrolled successfully', {
        enrollmentId: enrollment.id,
      });
      traceLogger.endSpan(spanId, 'success');

      return enrollment;
    } catch (error: any) {
      traceLogger.log('error', 'Enrollment', 'Enrollment failed', {
        error: error.message,
      });
      traceLogger.endSpan(spanId, 'error', { message: error.message });
      throw error;
    }
  }

  /**
   * Get all enrollments for a student
   */
  async getStudentEnrollments(userId: string): Promise<Enrollment[]> {
    const spanId = traceLogger.startSpan('Enrollment', 'getStudentEnrollments', { userId });

    try {
      traceLogger.log('info', 'Enrollment', 'Fetching student enrollments');

      const enrollments = await this.enrollmentRepo.getByUser(userId);

      traceLogger.log('success', 'Enrollment', 'Enrollments retrieved', {
        count: enrollments.length,
      });
      traceLogger.endSpan(spanId, 'success');

      return enrollments;
    } catch (error: any) {
      traceLogger.log('error', 'Enrollment', 'Failed to get enrollments', {
        error: error.message,
      });
      traceLogger.endSpan(spanId, 'error', { message: error.message });
      throw error;
    }
  }

  /**
   * Get all enrollments for a course (teacher view)
   */
  async getCourseEnrollments(courseId: string, teacherId: string): Promise<Enrollment[]> {
    const spanId = traceLogger.startSpan('Enrollment', 'getCourseEnrollments', {
      courseId,
      teacherId,
    });

    try {
      traceLogger.log('info', 'Enrollment', 'Verifying course ownership');

      // Verify teacher owns the course
      const course = await this.courseRepo.getById(courseId);
      if (course.teacherId !== teacherId) {
        throw new Error('Unauthorized: Only course owner can view enrollments');
      }

      traceLogger.log('info', 'Enrollment', 'Fetching course enrollments');
      const enrollments = await this.enrollmentRepo.getByCourse(courseId);

      traceLogger.log('success', 'Enrollment', 'Course enrollments retrieved', {
        count: enrollments.length,
      });
      traceLogger.endSpan(spanId, 'success');

      return enrollments;
    } catch (error: any) {
      traceLogger.log('error', 'Enrollment', 'Failed to get enrollments', {
        error: error.message,
      });
      traceLogger.endSpan(spanId, 'error', { message: error.message });
      throw error;
    }
  }

  /**
   * Unenroll a student from a course
   */
  async unenrollStudent(enrollmentId: string, userId: string): Promise<void> {
    const spanId = traceLogger.startSpan('Enrollment', 'unenrollStudent', {
      enrollmentId,
    });

    try {
      traceLogger.log('info', 'Enrollment', 'Fetching enrollment');

      const enrollment = await this.enrollmentRepo.getById(enrollmentId);

      // Verify ownership
      if (enrollment.userId !== userId) {
        throw new Error('Unauthorized: Cannot unenroll other users');
      }

      // Update status to dropped
      traceLogger.log('info', 'Enrollment', 'Marking enrollment as dropped');
      await this.enrollmentRepo.update(enrollmentId, {
        status: 'dropped',
      });

      traceLogger.log('success', 'Enrollment', 'Student unenrolled', {
        enrollmentId,
      });
      traceLogger.endSpan(spanId, 'success');
    } catch (error: any) {
      traceLogger.log('error', 'Enrollment', 'Unenroll failed', {
        error: error.message,
      });
      traceLogger.endSpan(spanId, 'error', { message: error.message });
      throw error;
    }
  }

  /**
   * Check if user is enrolled in a course
   */
  async isEnrolled(userId: string, courseId: string): Promise<boolean> {
    const spanId = traceLogger.startSpan('Enrollment', 'isEnrolled', {
      userId,
      courseId,
    });

    try {
      const enrollment = await this.enrollmentRepo.getByUserAndCourse(userId, courseId);

      const enrolled = enrollment !== null && enrollment.status === 'active';

      traceLogger.log('info', 'Enrollment', 'Enrollment check completed', {
        enrolled,
      });
      traceLogger.endSpan(spanId, 'success');

      return enrolled;
    } catch (error: any) {
      traceLogger.log('error', 'Enrollment', 'Enrollment check failed', {
        error: error.message,
      });
      traceLogger.endSpan(spanId, 'error', { message: error.message });
      throw error;
    }
  }

  /**
   * Get enrollment details (for student)
   */
  async getEnrollmentDetails(userId: string, courseId: string): Promise<Enrollment | null> {
    const spanId = traceLogger.startSpan('Enrollment', 'getEnrollmentDetails', {
      userId,
      courseId,
    });

    try {
      traceLogger.log('info', 'Enrollment', 'Fetching enrollment details');

      const enrollment = await this.enrollmentRepo.getByUserAndCourse(userId, courseId);

      if (enrollment && enrollment.userId !== userId) {
        throw new Error('Unauthorized: Cannot view other users enrollments');
      }

      traceLogger.log('success', 'Enrollment', 'Enrollment details retrieved', {
        found: enrollment !== null,
      });
      traceLogger.endSpan(spanId, 'success');

      return enrollment;
    } catch (error: any) {
      traceLogger.log('error', 'Enrollment', 'Failed to get enrollment details', {
        error: error.message,
      });
      traceLogger.endSpan(spanId, 'error', { message: error.message });
      throw error;
    }
  }
}
