"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Users, Award, Globe, ArrowRight, CheckCircle, Star, Play, Zap, Shield, Clock, Heart, Sparkles, Target, TrendingUp, Brain, Languages, Trophy, MessageCircle } from "lucide-react"
import { useState, useEffect } from "react"

export default function HomePage() {
  const [isVisible, setIsVisible] = useState(false)
  const [currentTestimonial, setCurrentTestimonial] = useState(0)

  useEffect(() => {
    setIsVisible(true)
    
    // Auto-rotate testimonials
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % 3)
    }, 5000)
    
    return () => clearInterval(interval)
  }, [])

  const testimonials = [
    {
      name: "Marta Kazlauskienė",
      role: "Lithuanian Language Teacher",
      content: "This platform is perfect for English speakers learning Lithuanian. The cultural context and grammar explanations are exactly what my students need!",
      rating: 5,
      avatar: "MK",
      flag: "🇱🇹"
    },
    {
      name: "Jonas Petras",
      role: "Software Engineer", 
      content: "As a Lithuanian speaker, the English courses here address all the specific challenges I face. The grammar explanations are incredibly helpful.",
      rating: 5,
      avatar: "JP",
      flag: "🇱🇹"
    },
    {
      name: "Dr. Paulius Rimkus",
      role: "University Professor",
      content: "The specialized approach for Lithuanian-English learning is outstanding. My students show remarkable progress using this platform.",
      rating: 5,
      avatar: "PR",
      flag: "🇱🇹"
    }
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50 overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-yellow-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-2000"></div>
        <div className="absolute top-40 left-1/2 w-80 h-80 bg-pink-300 rounded-full mix-blend-multiply filter blur-xl opacity-70 animate-pulse animation-delay-4000"></div>
      </div>


      {/* Hero Section */}
      <section className="relative py-20 px-4">
        <div className="container mx-auto text-center">
          <div className={`max-w-5xl mx-auto transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-indigo-100 text-indigo-800 text-sm font-medium mb-6 animate-pulse">
              <Sparkles className="h-4 w-4 mr-2" />
              New: AI-Powered Learning Paths
            </div>
            
            <h1 className="text-6xl md:text-7xl font-bold text-gray-900 mb-6 leading-tight">
              Master Lithuanian ↔ English
              <span className="block text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 animate-gradient-x">
                Language Learning
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl text-gray-600 mb-8 leading-relaxed max-w-3xl mx-auto">
              Join <span className="font-semibold text-indigo-600">5,000+</span> learners mastering Lithuanian and English with our specialized courses. 
              Learn at your own pace with AI-powered lessons, interactive quizzes, and real-time progress tracking designed specifically for Lithuanian-English language pairs.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button asChild size="lg" className="text-lg px-8 py-6 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <Link href="/auth/register">
                  Start Learning Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild className="btn-outline-primary text-lg px-8 py-6">
                <Link href="/courses">
                  <Play className="mr-2 h-5 w-5" />
                  Watch Demo
                </Link>
              </Button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap justify-center items-center gap-8 text-gray-500">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <span>No Credit Card Required</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <span>14-Day Free Trial</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-green-500" />
                <span>Cancel Anytime</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 bg-white/50 backdrop-blur-sm">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <Badge className="mb-4 px-4 py-2 text-sm border-2 border-indigo-600 text-indigo-600 hover:bg-indigo-50 bg-white">
              <Zap className="h-4 w-4 mr-2" />
              Why Choose Lithuanian-English Exchange?
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Master Lithuanian ↔ English
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600"> the Smart Way</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our specialized platform combines cutting-edge AI technology with proven learning methods 
              specifically designed for Lithuanian-English language pairs. Experience unparalleled learning that adapts to your pace and cultural context.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                icon: Brain,
                title: "AI-Powered Lessons",
                description: "Personalized learning paths that adapt to your progress and learning style for maximum efficiency.",
                color: "blue",
                gradient: "from-blue-500 to-cyan-500"
              },
              {
                icon: Users,
                title: "Expert Instructors",
                description: "Learn from certified language teachers and native speakers with years of teaching experience.",
                color: "green",
                gradient: "from-green-500 to-emerald-500"
              },
              {
                icon: Award,
                title: "Smart Progress Tracking",
                description: "Advanced analytics show your strengths, weaknesses, and personalized recommendations for improvement.",
                color: "purple",
                gradient: "from-purple-500 to-pink-500"
              },
              {
                icon: Globe,
                title: "Global Community",
                description: "Connect with 50,000+ learners worldwide, practice conversations, and immerse in diverse cultures.",
                color: "orange",
                gradient: "from-orange-500 to-red-500"
              },
              {
                icon: Shield,
                title: "Secure & Private",
                description: "Your data is protected with enterprise-grade security. Learn with complete peace of mind.",
                color: "indigo",
                gradient: "from-indigo-500 to-blue-500"
              },
              {
                icon: Clock,
                title: "Flexible Learning",
                description: "Study anytime, anywhere with 24/7 access. Perfect for busy schedules and different time zones.",
                color: "pink",
                gradient: "from-pink-500 to-rose-500"
              }
            ].map((feature, index) => (
              <Card key={index} className="group hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 border-0 bg-white/80 backdrop-blur-sm">
                <CardHeader className="text-center p-8">
                  <div className={`w-16 h-16 bg-gradient-to-r ${feature.gradient} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-indigo-600 transition-colors">
                    {feature.title}
                  </CardTitle>
            </CardHeader>
                <CardContent className="px-8 pb-8">
                  <CardDescription className="text-base text-gray-600 leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
          </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Language Showcase */}
      <section className="py-20 px-4 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto relative">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Specialized Lithuanian ↔ English Learning
            </h2>
            <p className="text-xl opacity-90 max-w-2xl mx-auto">
              Focused exclusively on Lithuanian and English language learning with courses designed specifically for both directions of learning.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-center max-w-4xl mx-auto">
            {[
              { 
                name: "English to Lithuanian", 
                flag: "🇱🇹", 
                learners: "2,847", 
                description: "Master Lithuanian from English with comprehensive courses covering grammar, vocabulary, and cultural context.",
                courses: "4 courses available"
              },
              { 
                name: "Lithuanian to English", 
                flag: "🇺🇸", 
                learners: "2,153", 
                description: "Develop fluent English skills from Lithuanian with specialized lessons addressing common challenges for Lithuanian speakers.",
                courses: "4 courses available"
              }
            ].map((language, index) => (
              <div key={index} className="group hover:scale-105 transition-all duration-300 bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
                <div className="text-6xl mb-4 group-hover:scale-125 transition-transform">
                  {language.flag}
                </div>
                <div className="font-bold text-2xl mb-2">{language.name}</div>
                <div className="text-lg opacity-90 mb-4">{language.learners} active learners</div>
                <div className="text-sm opacity-75 mb-4">{language.courses}</div>
                <div className="text-sm opacity-90 leading-relaxed">{language.description}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Join Our Lithuanian-English Learning Community
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Thousands of learners trust our specialized platform for Lithuanian-English language learning. 
              See what makes us the premier choice for this language pair.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 text-center">
            {[
              { number: "5,000+", label: "Active Learners", icon: Users, color: "from-blue-500 to-cyan-500" },
              { number: "2", label: "Specialized Languages", icon: Languages, color: "from-green-500 to-emerald-500" },
              { number: "8", label: "Expert Courses", icon: Award, color: "from-purple-500 to-pink-500" },
              { number: "96%", label: "Success Rate", icon: TrendingUp, color: "from-orange-500 to-red-500" }
            ].map((stat, index) => (
              <div key={index} className="group">
                <div className={`w-16 h-16 bg-gradient-to-r ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                  <stat.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-4xl md:text-5xl font-bold mb-2 group-hover:scale-110 transition-transform text-gray-900">
                  {stat.number}
                </div>
                <div className="text-lg text-gray-600">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              What Our Learners Say
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it. Here's what our community has to say about their learning experience.
            </p>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="p-8 bg-white shadow-xl">
              <CardContent className="text-center">
                <div className="flex justify-center mb-6">
                  {[...Array(testimonials[currentTestimonial].rating)].map((_, i) => (
                    <Star key={i} className="h-6 w-6 text-yellow-400 fill-current" />
                  ))}
                </div>
                <blockquote className="text-xl text-gray-700 mb-6 italic">
                  "{testimonials[currentTestimonial].content}"
                </blockquote>
                <div className="flex items-center justify-center">
                  <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full flex items-center justify-center text-white font-semibold mr-4">
                    {testimonials[currentTestimonial].avatar}
                  </div>
                  <div className="text-left">
                    <div className="font-semibold text-gray-900 text-lg">
                      {testimonials[currentTestimonial].name}
                    </div>
                    <div className="text-gray-500">
                      {testimonials[currentTestimonial].role} {testimonials[currentTestimonial].flag}
                    </div>
                  </div>
                </div>
              </CardContent>
          </Card>

            <div className="flex justify-center mt-6 space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentTestimonial(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentTestimonial ? 'bg-indigo-600' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-br from-indigo-600 to-purple-700 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="container mx-auto text-center relative">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-4xl md:text-5xl font-bold mb-6">
              Ready to Master Lithuanian ↔ English?
            </h2>
            <p className="text-xl md:text-2xl mb-8 opacity-90">
              Join thousands of successful learners who have achieved fluency in Lithuanian and English with our specialized platform. 
              Start your journey today and see results in just 30 days.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Button asChild size="lg" className="text-lg px-8 py-6 bg-white text-indigo-600 hover:bg-gray-100 shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105">
                <Link href="/auth/register">
                  <Heart className="mr-2 h-5 w-5" />
                  Start Your Free Trial
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild className="btn-outline-white text-lg px-8 py-6">
                <Link href="/courses">
                  <Target className="mr-2 h-5 w-5" />
                  Explore Courses
                </Link>
              </Button>
            </div>
            <p className="text-sm opacity-75">
              ✨ No credit card required • 14-day free trial • Cancel anytime
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-5 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center space-x-2 mb-6">
                <span className="text-2xl">🇱🇹🇺🇸</span>
                <span className="font-bold text-2xl bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">
                  Lithuanian-English Exchange
                </span>
              </div>
              <p className="text-gray-400 mb-6 max-w-md">
                Empowering learners to master Lithuanian and English through 
                specialized, interactive, and culturally-aware learning experiences.
              </p>
              <div className="flex space-x-4">
                {['Twitter', 'Facebook', 'LinkedIn', 'Instagram'].map((social) => (
                  <div key={social} className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-indigo-600 transition-colors cursor-pointer">
                    <span className="text-sm font-semibold">{social[0]}</span>
                  </div>
                ))}
              </div>
            </div>
            
            {[
              {
                title: "Platform",
                links: ["Browse Courses", "Pricing", "About Us", "Contact", "Blog"]
              },
              {
                title: "Support",
                links: ["Help Center", "FAQ", "Community", "Tutorials", "Status"]
              },
              {
                title: "Legal",
                links: ["Privacy Policy", "Terms of Service", "Cookie Policy", "GDPR", "Accessibility"]
              }
            ].map((section, index) => (
              <div key={index}>
                <h3 className="font-semibold mb-4 text-lg">{section.title}</h3>
                <ul className="space-y-3">
                  {section.links.map((link) => (
                    <li key={link}>
                      <Link href="#" className="text-gray-400 hover:text-white transition-colors">
                        {link}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          
          <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-sm">
              &copy; 2024 Lithuanian-English Exchange. All rights reserved.
            </p>
            <div className="flex items-center space-x-6 mt-4 md:mt-0">
              <span className="text-gray-400 text-sm">Made with ❤️ for Lithuanian-English learners</span>
            </div>
        </div>
      </div>
      </footer>
    </div>
  )
}