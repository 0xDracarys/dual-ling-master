/**
 * Course Progress API Routes
 * GET - Get user progress for courses/lessons
 * POST - Update progress for a lesson
 *
 * TODO: Implement with Firebase ProgressService (Phase 3 Week 3)
 * Currently disabled to avoid MongoDB dependency
 */

import { type NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  return NextResponse.json(
    {
      success: false,
      error: 'Progress tracking not yet implemented in Firebase migration',
    },
    { status: 501 } // Not Implemented
  );
}

export async function GET(request: NextRequest) {
  return NextResponse.json(
    {
      success: false,
      error: 'Progress tracking not yet implemented in Firebase migration',
      data: {
        progress: [],
      },
    },
    { status: 501 } // Not Implemented
  );
}
