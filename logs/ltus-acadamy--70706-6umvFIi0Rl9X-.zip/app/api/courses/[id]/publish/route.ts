/**
 * Course Publish/Unpublish API Route
 * POST - Toggle course published status
 *
 * Phase 3 Week 1.5: Firebase Migration
 */

import { type NextRequest, NextResponse } from 'next/server';
import { CourseService } from '@/lib/services/course/course.service';
import { traceLogger } from '@/lib/tracing/trace-logger';
import { z } from 'zod';

const courseService = new CourseService();

const publishSchema = z.object({
  action: z.enum(['publish', 'unpublish']),
});

/**
 * POST /api/courses/[id]/publish
 * Publish or unpublish a course (teacher only)
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id: courseId } = await params;
  const spanId = traceLogger.startSpan('API', 'POST /api/courses/[id]/publish', { courseId });

  try {
    traceLogger.log('info', 'API', 'Publish/unpublish request received', { courseId });

    // TODO: Get teacherId from Firebase Auth session
    const teacherId = request.headers.get('X-Teacher-Id') || 'TEMP_TEACHER_ID';

    const body = await request.json();
    const { action } = publishSchema.parse(body);

    traceLogger.log('info', 'API', `Attempting to ${action} course`, { courseId });

    if (action === 'publish') {
      await courseService.publishCourse(courseId, teacherId);
    } else {
      await courseService.unpublishCourse(courseId, teacherId);
    }

    traceLogger.log('success', 'API', `Course ${action}ed successfully`, { courseId });
    traceLogger.endSpan(spanId, 'success');

    return NextResponse.json(
      {
        success: true,
        message: `Course ${action}ed successfully`,
      },
      { status: 200 }
    );
  } catch (error: any) {
    if (error.name === 'ZodError') {
      traceLogger.log('warn', 'API', 'Validation error', { errors: error.errors });
      traceLogger.endSpan(spanId, 'error', { message: 'Validation failed' });
      return NextResponse.json(
        {
          success: false,
          error: 'Validation error',
          details: error.errors,
        },
        { status: 400 }
      );
    }

    traceLogger.log('error', 'API', 'Publish/unpublish failed', {
      error: error.message,
      courseId,
    });
    traceLogger.endSpan(spanId, 'error', { message: error.message });

    const statusCode = error.message.includes('Unauthorized')
      ? 403
      : error.message.includes('not found')
      ? 404
      : error.message.includes('no lessons')
      ? 400
      : 500;

    return NextResponse.json(
      {
        success: false,
        error: error.message,
      },
      { status: statusCode }
    );
  }
}
