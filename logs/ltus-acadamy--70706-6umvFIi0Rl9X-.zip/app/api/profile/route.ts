/**
 * User Profile API Routes
 * GET - Get user profile
 * PUT - Update user profile
 *
 * TODO: Implement with Firebase UserRepository (Phase 3)
 * Currently disabled to avoid MongoDB dependency
 */

import { type NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  return NextResponse.json(
    {
      success: false,
      error: 'User profile not yet implemented in Firebase migration',
      message: 'Please use Firebase UserRepository to fetch user data',
    },
    { status: 501 } // Not Implemented
  );
}

export async function PUT(request: NextRequest) {
  return NextResponse.json(
    {
      success: false,
      error: 'Profile update not yet implemented in Firebase migration',
    },
    { status: 501 } // Not Implemented
  );
}
