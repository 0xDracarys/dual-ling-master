import type React from "react"
import type { Metadata } from "next"
import { AuthProvider } from "@/hooks/use-auth"
import { Navbar } from "@/components/navigation/navbar"
import { DebugPanel } from "@/components/debug/DebugPanel"
import "./globals.css"

export const metadata: Metadata = {
  title: "LangExchange - Language Learning Platform",
  description: "Learn Lithuanian and English through interactive courses",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="light">
      <body className="font-sans bg-white text-gray-900">
        <AuthProvider>
          <Navbar />
          {children}
          <DebugPanel />
        </AuthProvider>
      </body>
    </html>
  )
}
